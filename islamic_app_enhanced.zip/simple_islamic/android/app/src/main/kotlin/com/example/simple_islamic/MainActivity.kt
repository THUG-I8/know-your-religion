package com.example.simple_islamic

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
